Licencia de Desarrollador

Este proyecto está protegido bajo una licencia de desarrollador. Esto significa que:

Puedes:
- Usar el código para tus propios proyectos.
- Modificar el código para adaptarlo a tus necesidades.

No puedes:
- Redistribuir el código a terceros.
- Revender el código o cualquier derivado del mismo.

Términos de la Licencia:
1. Uso único: Este software es para uso exclusivo del comprador original. No está permitido compartirlo, redistribuirlo o revenderlo.
2. Modificaciones: Puedes modificar el código para tus propios proyectos, pero no puedes distribuir las modificaciones a terceros.
3. Propiedad intelectual: El autor retiene todos los derechos de propiedad intelectual sobre el código original.

Si deseas obtener una licencia para redistribuir o revender este software, por favor contáctame al correo: sanabriajonathan2000@gmail.com

Soporte:
Si tienes alguna pregunta o necesitas ayuda con la configuración o el uso de este proyecto, no dudes en contactarme:
- Email: sanabriajonathan2000@gmail.com
- Sitio web: 

Ejemplo de Uso:
- Cliente: Accede a http://<tu-ip>:3000 para ver el menú y realizar pedidos.
- Cocina: Accede a http://<tu-ip>:3000/cocina para ver las órdenes en tiempo real.
- Administrador: Accede a http://<tu-ip>:3000/admin para gestionar el menú (agregar, editar o eliminar productos).

¡Gracias por adquirir este proyecto! Si tienes alguna pregunta o necesitas soporte, no dudes en contactarme.

Notas Adicionales:
- CORS: El servidor está configurado para permitir conexiones desde cualquier origen (*). Si deseas restringir el acceso, modifica la configuración de CORS en server.js.
- Puerto: El servidor escucha en el puerto 3000 por defecto. Puedes cambiarlo modificando la variable PORT en server.js.