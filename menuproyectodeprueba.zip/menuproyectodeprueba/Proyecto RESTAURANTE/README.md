Menú Interactivo - Documentación
Este proyecto es un menú interactivo que permite a los clientes realizar pedidos y a los administradores gestionar el menú. El sistema está construido con Node.js en el backend y utiliza WebSockets para la comunicación en tiempo real.

Requisitos
Node.js (v14 o superior)

NPM (v6 o superior)

Instalación:

Descarga el archivo ZIP y extraelo, abre la carpeta en visual studio code y sigue los siguientes pasos:  

Instala las dependencias:

bash
Copy
npm install
Configura la IP local:
Para que el servidor funcione en tu red local, debes modificar la IP en los siguientes archivos:

server.js:
Cambia la variable IP en la línea donde se define:

javascript
Copy
const IP = '192.168.100.211'; // Cambia a tu IP local
Reemplaza 192.168.100.211 con la IP de tu máquina en la red local.

Archivos del Frontend:
Si tienes archivos HTML o JavaScript en el frontend que se conectan al servidor (por ejemplo, en index.html, cocina.html, o admin.html), asegúrate de que las URLs de conexión al servidor también apunten a tu IP local. Por ejemplo:

javascript
Copy
const socket = io('http://192.168.100.211:3000'); // Cambia a tu IP local
Inicia el servidor:

bash
Copy
npm start
Accede al menú:

Menú principal: Abre en tu navegador http://<tu-ip>:3000.

Cocina: Abre en tu navegador http://<tu-ip>:3000/cocina.

Panel de administración: Abre en tu navegador http://<tu-ip>:3000/admin.

Reemplaza <tu-ip> con la IP que configuraste en el paso 3.

Estructura del Proyecto
server.js: El servidor backend que maneja las órdenes, el menú y la comunicación en tiempo real.

menu.json: Archivo JSON donde se almacenan los productos del menú.

frontend/: Contiene los archivos HTML, CSS y JavaScript del frontend.

index.html: Página principal del menú para los clientes.

cocina.html: Interfaz para la cocina donde se ven las órdenes.

admin.html: Panel de administración para gestionar el menú.

Configuración del Panel de Administración
El panel de administración está protegido con autenticación básica. Las credenciales predeterminadas son:

Usuario: admin

Contraseña: admin123

Puedes cambiar estas credenciales en el archivo server.js en la sección del middleware de autenticación:

javascript
Copy
const auth = { login: 'admin', password: 'admin123' };

Persistencia de Datos
Los productos del menú se guardan en el archivo menu.json. Cada vez que se realiza una operación CRUD (Crear, Leer, Actualizar, Eliminar) en el menú, los cambios se guardan automáticamente en este archivo. Esto permite que los datos persistan incluso después de reiniciar el servidor.